var width=window.innerWidth;
var height=window.innerHeight;
if (width>=1024) {
	var height=window.innerHeight;
	$('.slider_img').css("height",height);
}
